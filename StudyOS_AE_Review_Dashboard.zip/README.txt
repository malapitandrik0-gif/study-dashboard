STUDYOS — AE REVIEW DASHBOARD

How to use:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge/Firefox.
3. Your progress is saved automatically in the browser using localStorage.
4. Keep the materials folder beside index.html so source-document links work.

Included:
- Dashboard with subject/topic progress
- Topic tracker with completion states
- Quick summaries and exam-review prompts for all mapped topics
- Bundled source-document resources
- Supplied exam reviewers
- Quiz mode based on the supplied answered quiz

Note: This is a self-contained offline website; no account or server is required.
